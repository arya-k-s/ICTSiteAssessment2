package com.ict.constants;

public class AutomationConstants {
	
	public static String expusername="practice.swtesting@gmail.com";
	public static String exppassword="123";
	public static String checklogin="Admin";
	public static String expname="Arya ks";
	public static String exppassword1="Arya";
	public static String expemail="arya@gmail.com";
	public static String expempid="2020";
	public static String expconfirmpassword="Arya";
	public static String expphone="9048436333";
	public static String expaddress="Kunnathukudiyil,muvattupuzha";
	public static String expnewempid="2021";
			
	

}
